# Nexus Launcher

Cyberpunk-themed Android home launcher.

## What's here

- **Gradle project** (Kotlin DSL), Cyberpunk theme, adaptive icon — see git
  history for the original Milestone 1 scaffold notes.
- **Arc-wheel app drawer** (`drawer/`) — circular drag-to-scroll launcher
  backed by `InstalledAppsRepository`.
- **Orbit HUD** (`hud/`) — home root: live clock (tap → system Alarms) and
  date (tap → system Calendar), weather ring (currently a labeled mock —
  see `WeatherRepository`), a real RAM booster (`RamBoosterRepository`,
  `PACKAGE_USAGE_STATS`-gated), and quick launchers for the dialer and news
  feed.
- **Double-tap-to-lock** (`security/`) — minimal `AccessibilityService`
  whose only job is `performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)`;
  gesture detection itself lives in Compose on the HUD.
- **Voice assistant** (`voice/`) — `SpeechRecognizer`-backed "Open X" /
  "Boost RAM" / "Lock Screen" commands, glowing mic orb with a ripple
  listening animation.
- **Custom dialer** (`dialer/`) — keypad, saved contacts, dual-SIM calling
  via `TelecomManager`.
- **News feed** (`newsfeed/`) — RSS 2.0 fetch + parse (`XmlPullParser`),
  defaults to BBC News; swap `RssRepository.DEFAULT_FEED_URL` for any feed.
- **`LauncherRoot`** (`core/`) — hosts the Orbit HUD and app drawer together;
  swipe up on the HUD opens the drawer as a sliding overlay, a grab handle
  at the drawer's top (or system Back, or pressing Home) closes it again.

## Permissions that need special handling (not just a runtime dialog)

- `PACKAGE_USAGE_STATS` — user must grant via Settings > Usage Access,
  no system dialog exists for it.
- Accessibility Settings — same idea, for the double-tap-lock service.
- `SYSTEM_ALERT_WINDOW` — user must grant via Settings > "Display over other
  apps"; not yet used by any implemented feature.
- `WRITE_SETTINGS` — same pattern, Settings > "Modify system settings";
  not yet used.
- `QUERY_ALL_PACKAGES` — Play Store requires a declaration form justifying
  use for launcher apps at publish time; functionally fine for local builds.

## Not yet included (by design)

- Real weather API call (`WeatherRepository` is an intentional, labeled
  mock — see its doc comment for the swap point).
- Assistive Touch overlay ball, GameBoosterService, Settings/Security
  screens.
- Custom font (Chakra Petch/Orbitron) — `HudFontFamily` in `Type.kt` is a
  single line to swap once a Google Font or bundled `.ttf` is added.

## Build

Open in Android Studio (Koala+) or:

```bash
./gradlew assembleDebug
```

Note: this export doesn't include the Gradle wrapper jar/scripts — Android
Studio will offer to generate them on first open, or run
`gradle wrapper --gradle-version 8.7` if building from the CLI.

Nothing in this export has been through an actual Gradle build in the
environment it was written in (no Android SDK/network there) — do a build
pass before trusting any of it, especially the newer voice/dialer/RSS code,
which touches several permission flows and platform APIs at once.
