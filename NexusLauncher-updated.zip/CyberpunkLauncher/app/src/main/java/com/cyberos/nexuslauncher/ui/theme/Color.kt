package com.cyberos.nexuslauncher.ui.theme

import androidx.compose.ui.graphics.Color

// ---- Base surfaces: near-black with a cold blue tint, never true #000 ----
val VoidBlack = Color(0xFF05070D)
val DeepSpace = Color(0xFF0B0F1A)
val PanelInk = Color(0xFF11172A)
val PanelInkRaised = Color(0xFF1A2138)
val GridLine = Color(0xFF232B45)

// ---- Neon accents ----
val NeonCyan = Color(0xFF00F0FF)
val NeonCyanDim = Color(0xFF0AA6B3)
val NeonMagenta = Color(0xFFFF2ED1)
val NeonMagentaDim = Color(0xFFB01E96)
val NeonPurple = Color(0xFFB026FF)
val NeonAmber = Color(0xFFFFB800)
val NeonGreen = Color(0xFF39FF14)
val AlertRed = Color(0xFFFF3B5C)

// ---- Text ----
val TextPrimary = Color(0xFFE7F6FF)
val TextSecondary = Color(0xFF8CA0C4)
val TextDisabled = Color(0xFF4A5674)

// ---- Gradients (used for the Orbit HUD ring + glow washes) ----
val OrbitGradientStart = NeonCyan
val OrbitGradientEnd = NeonPurple
