package com.cyberos.nexuslauncher.dialer

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.telecom.PhoneAccountHandle
import android.telecom.TelecomManager
import androidx.core.content.ContextCompat

data class SimAccount(
    val handle: PhoneAccountHandle,
    val label: String
)

/**
 * TelecomManager over an implicit ACTION_CALL Intent for one reason: only
 * TelecomManager.placeCall() accepts EXTRA_PHONE_ACCOUNT_HANDLE to pin a
 * specific SIM. ACTION_CALL always leaves SIM selection to the system (a
 * picker dialog, or whichever is default) — there's no way to preselect
 * SIM 1 vs SIM 2 through it.
 */
object TelecomCallRepository {

    /** Empty on a single-SIM device, or if READ_PHONE_STATE isn't granted. */
    fun listCallCapableAccounts(context: Context): List<SimAccount> {
        if (!hasPermission(context, Manifest.permission.READ_PHONE_STATE)) return emptyList()

        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            ?: return emptyList()

        return runCatching {
            telecomManager.callCapablePhoneAccounts.mapIndexed { index, handle ->
                val account = runCatching { telecomManager.getPhoneAccount(handle) }.getOrNull()
                SimAccount(
                    handle = handle,
                    label = account?.label?.toString()?.takeIf { it.isNotBlank() } ?: "SIM ${index + 1}"
                )
            }
        }.getOrDefault(emptyList())
    }

    /** No-op if CALL_PHONE isn't granted — caller is expected to have gated on that already. */
    fun placeCall(context: Context, phoneNumber: String, account: SimAccount?) {
        if (!hasPermission(context, Manifest.permission.CALL_PHONE)) return

        val telecomManager = context.getSystemService(Context.TELECOM_SERVICE) as? TelecomManager
            ?: return

        val extras = Bundle().apply {
            if (account != null) {
                putParcelable(TelecomManager.EXTRA_PHONE_ACCOUNT_HANDLE, account.handle)
            }
        }

        runCatching {
            telecomManager.placeCall(Uri.fromParts("tel", phoneNumber, null), extras)
        }
    }

    private fun hasPermission(context: Context, permission: String): Boolean =
        ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
}
