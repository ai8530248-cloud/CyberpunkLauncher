package com.cyberos.nexuslauncher.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.ui.unit.dp

// Cyberpunk panels favor faceted corners over soft rounding — one corner
// square, others cut — but Material3's Shapes only takes RoundedCornerShape,
// so we keep those subtle here and do true angular cuts with a custom
// GenericShape at the composable level (HUD ring, panel edges) later.
val NexusShapes = Shapes(
    extraSmall = RoundedCornerShape(2.dp),
    small = RoundedCornerShape(4.dp),
    medium = RoundedCornerShape(8.dp),
    large = RoundedCornerShape(0.dp, 16.dp, 0.dp, 16.dp), // faceted card corner
    extraLarge = RoundedCornerShape(24.dp)
)
