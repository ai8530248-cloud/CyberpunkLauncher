package com.cyberos.nexuslauncher.dialer

import android.Manifest
import androidx.compose.runtime.Composable
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.MultiplePermissionsState
import com.google.accompanist.permissions.rememberMultiplePermissionsState

/**
 * All three permissions the dialer needs, requested together: CALL_PHONE and
 * READ_CONTACTS for the dial pad + saved contacts, READ_PHONE_STATE because
 * [TelecomCallRepository.listCallCapableAccounts] needs it to actually see
 * the SIM list — without it the dual-SIM buttons never appear, silently
 * degrading to single-SIM behavior instead of doing what was asked for.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun rememberDialerPermissionsState(): MultiplePermissionsState =
    rememberMultiplePermissionsState(
        listOf(
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.READ_PHONE_STATE
        )
    )
