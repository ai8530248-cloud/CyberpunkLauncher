package com.cyberos.nexuslauncher.hud

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

enum class WeatherCondition(val glyph: String) {
    CLEAR("☀"),
    CLOUDS("☁"),
    RAIN("☂"),
    SNOW("❄"),
    STORM("⚡")
}

data class WeatherSnapshot(
    val tempC: Int,
    val condition: WeatherCondition,
    val locationLabel: String
)

/**
 * Weather source for the Orbit ring.
 *
 * INTENTIONALLY A MOCK for this milestone: a real implementation needs a
 * provider (OpenWeatherMap, Open-Meteo, etc.), an API key, and turning
 * ACCESS_COARSE_LOCATION (already declared in the manifest for this) into an
 * actual FusedLocationProvider call. Wiring a fake API key in here would
 * build cleanly and then silently fail on-device, which is worse than an
 * honest stub — so [currentWeather] returns a fixed snapshot after a short
 * simulated delay, matching the async shape the real call will have.
 *
 * Swap point for the next milestone: replace the body of [currentWeather]
 * with a real network call; [OrbitHudScreen] and [OrbitRing] don't need to
 * change at all since they only depend on [WeatherSnapshot].
 */
object WeatherRepository {

    suspend fun currentWeather(context: Context): WeatherSnapshot = withContext(Dispatchers.IO) {
        delay(300) // stand-in for network latency so loading states are real
        WeatherSnapshot(
            tempC = 21,
            condition = WeatherCondition.CLOUDS,
            locationLabel = "—"
        )
    }
}
