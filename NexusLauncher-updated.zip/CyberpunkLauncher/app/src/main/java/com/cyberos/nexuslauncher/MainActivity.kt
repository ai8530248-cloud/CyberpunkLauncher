package com.cyberos.nexuslauncher

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.material3.Surface
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import com.cyberos.nexuslauncher.core.LauncherRoot
import com.cyberos.nexuslauncher.ui.theme.NexusLauncherTheme

/**
 * Home screen root activity.
 *
 * Standalone launchers get relaunched with a fresh Intent every time the user
 * presses Home while already at the home screen — [onNewIntent] bumps
 * [homeSignal], which [LauncherRoot] watches to collapse the app drawer back
 * to the Orbit HUD, mirroring real launcher "press Home to go Home" behavior.
 */
class MainActivity : ComponentActivity() {

    private var homeSignal by mutableIntStateOf(0)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            NexusLauncherTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    LauncherRoot(collapseSignal = homeSignal)
                }
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        homeSignal++
    }
}
