package com.cyberos.nexuslauncher.core

import android.app.Application

/**
 * Application entry point.
 *
 * Intentionally minimal for the scaffold milestone. This is where later
 * milestones will hook in:
 *   - DataStore-backed SettingsRepository (icon size, hidden apps, ball opacity...)
 *   - A process-wide CoroutineScope for the RAM/Game booster watchers
 *   - Crash/ANR logging
 * No dependency injection framework is wired up yet on purpose — adding Hilt
 * here now, before there's more than one screen, would be pure ceremony.
 */
class LauncherApplication : Application() {

    override fun onCreate() {
        super.onCreate()
    }
}
