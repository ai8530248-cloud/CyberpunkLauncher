package com.cyberos.nexuslauncher.hud

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.CalendarContract
import android.widget.Toast

/**
 * Both of these are the standard, permission-free way to jump into another
 * system app's UI — ACTION_SHOW_ALARMS and a CalendarContract "time" URI
 * with ACTION_VIEW. Neither needs READ_CALENDAR or any alarm permission
 * since we're not querying either provider directly, just asking the OS to
 * open the app that owns it.
 */
object HudIntents {

    fun openAlarms(context: Context) {
        val intent = Intent(AlarmClock.ACTION_SHOW_ALARMS)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchOrToast(context, intent, "No clock app found")
    }

    fun openCalendarToday(context: Context) {
        val todayUri = CalendarContract.CONTENT_URI.buildUpon()
            .appendPath("time")
            .appendPath(System.currentTimeMillis().toString())
            .build()
        val intent = Intent(Intent.ACTION_VIEW, todayUri)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        launchOrToast(context, intent, "No calendar app found")
    }

    private fun launchOrToast(context: Context, intent: Intent, failureMessage: String) {
        runCatching { context.startActivity(intent) }
            .onFailure { Toast.makeText(context, failureMessage, Toast.LENGTH_SHORT).show() }
    }
}
