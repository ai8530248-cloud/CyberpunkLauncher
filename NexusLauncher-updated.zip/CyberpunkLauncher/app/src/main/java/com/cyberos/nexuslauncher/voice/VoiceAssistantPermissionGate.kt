package com.cyberos.nexuslauncher.voice

import android.Manifest
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.ui.theme.GridLine
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.PanelInk
import com.cyberos.nexuslauncher.ui.theme.TextDisabled
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.PermissionStatus
import com.google.accompanist.permissions.rememberPermissionState

/**
 * Wraps [content] — meant to be [VoiceMicOrb] — and only renders it once
 * RECORD_AUDIO is granted. Below that, renders a same-sized placeholder so
 * the mic's spot in the layout doesn't jump around as permission state changes.
 *
 * This is the top-level entry point for dropping the voice assistant into
 * any screen: `VoiceAssistantEntryPoint()` is all a caller needs.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun VoiceAssistantPermissionGate(
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    val micPermission = rememberPermissionState(Manifest.permission.RECORD_AUDIO)

    // accompanist's shouldShowRationale is false both "never asked yet" and
    // "permanently denied" — those need different copy, so track whether a
    // request was actually made ourselves rather than trusting that flag alone.
    var hasRequestedOnce by rememberSaveable { mutableStateOf(false) }

    when (micPermission.status) {
        is PermissionStatus.Granted -> content()

        is PermissionStatus.Denied -> {
            val status = micPermission.status as PermissionStatus.Denied
            PermissionPrompt(
                modifier = modifier,
                permanentlyDenied = hasRequestedOnce && !status.shouldShowRationale,
                onRequestClick = {
                    hasRequestedOnce = true
                    micPermission.launchPermissionRequest()
                }
            )
        }
    }
}

@Composable
private fun PermissionPrompt(
    modifier: Modifier = Modifier,
    permanentlyDenied: Boolean,
    onRequestClick: () -> Unit
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Filled.Mic,
            contentDescription = "Grant microphone permission",
            tint = TextDisabled,
            modifier = Modifier
                .size(72.dp)
                .clip(CircleShape)
                .background(PanelInk)
                .border(1.dp, GridLine, CircleShape)
                .clickable(enabled = !permanentlyDenied, onClick = onRequestClick)
                .padding(20.dp)
        )
        Text(
            text = if (permanentlyDenied) {
                "Mic access denied — enable it in system Settings to use voice commands"
            } else {
                "Tap to allow microphone access for voice commands"
            },
            color = if (permanentlyDenied) TextDisabled else NeonCyan,
            style = MaterialTheme.typography.labelSmall,
            modifier = Modifier.padding(top = 8.dp)
        )
    }
}
