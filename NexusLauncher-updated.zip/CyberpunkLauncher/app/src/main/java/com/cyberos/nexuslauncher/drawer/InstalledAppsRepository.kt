package com.cyberos.nexuslauncher.drawer

import android.content.Context
import android.content.Intent
import android.content.pm.ResolveInfo
import android.graphics.drawable.Drawable
import android.widget.Toast
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.graphics.drawable.toBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * Real installed-apps source for the drawer, replacing the earlier
 * hand-written preview list.
 *
 * Deliberately queries `ACTION_MAIN` + `CATEGORY_LAUNCHER` via
 * [android.content.pm.PackageManager.queryIntentActivities] rather than
 * [android.content.pm.PackageManager.getInstalledApplications]:
 *   - It only returns activities with a visible launcher entry, which is
 *     what a drawer should show (getInstalledApplications also returns
 *     background-only apps, services-only apps, etc. that have no icon to
 *     tap).
 *   - Package visibility: apps that themselves declare an ACTION_MAIN /
 *     CATEGORY_HOME intent filter — which this app does, in the manifest —
 *     get an automatic Android package-visibility exemption to see every
 *     other app's launcher activities. That's *this specific query*, so it
 *     works without needing the QUERY_ALL_PACKAGES Play Store declaration
 *     form even though the manifest also declares that permission as a
 *     belt-and-suspenders fallback.
 */
object InstalledAppsRepository {

    suspend fun loadLaunchableApps(context: Context): List<AppIconData> =
        withContext(Dispatchers.IO) {
            val pm = context.packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val resolved: List<ResolveInfo> = pm.queryIntentActivities(launcherIntent, 0)

            resolved
                .distinctBy { it.activityInfo.packageName }
                .mapNotNull { resolveInfo ->
                    runCatching {
                        val appInfo = resolveInfo.activityInfo.applicationInfo
                        AppIconData(
                            packageName = resolveInfo.activityInfo.packageName,
                            label = resolveInfo.loadLabel(pm).toString(),
                            icon = resolveInfo.loadIcon(pm).toIconBitmap(),
                            category = AppCategory.fromApplicationInfoCategory(appInfo.category)
                        )
                    }.getOrNull() // a handful of system/OEM packages throw on loadIcon/loadLabel — skip, don't crash the whole scan
                }
                .sortedBy { it.label.lowercase() }
        }

    fun launchApp(context: Context, packageName: String) {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName)
        if (intent != null) {
            context.startActivity(intent)
        } else {
            // Package was uninstalled between the scan and the tap, or has no
            // launch intent anymore — fail loud enough to notice, not with a crash.
            Toast.makeText(context, "Can't open that app anymore", Toast.LENGTH_SHORT).show()
        }
    }

    private fun Drawable.toIconBitmap(sizePx: Int = 128): ImageBitmap =
        toBitmap(width = sizePx, height = sizePx).asImageBitmap()
}
