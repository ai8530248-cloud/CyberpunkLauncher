package com.cyberos.nexuslauncher.dialer

import android.content.Context
import android.provider.ContactsContract
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class ContactInfo(
    val id: String,
    val displayName: String,
    val phoneNumber: String
)

/**
 * Queries ContactsContract.CommonDataKinds.Phone directly (not the
 * Contacts table) since that's the join that already carries a usable phone
 * number per row — querying Contacts and then Phone per-contact would be
 * one query per person instead of one query total.
 */
object ContactsRepository {

    suspend fun loadContactsWithNumbers(context: Context, limit: Int = 60): List<ContactInfo> =
        withContext(Dispatchers.IO) {
            val results = mutableListOf<ContactInfo>()
            val seenNumbers = HashSet<String>()

            val projection = arrayOf(
                ContactsContract.CommonDataKinds.Phone._ID,
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            )

            runCatching {
                context.contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection,
                    null,
                    null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )?.use { cursor ->
                    val idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone._ID)
                    val nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)

                    while (cursor.moveToNext() && results.size < limit) {
                        val name = cursor.getString(nameIdx)?.takeIf { it.isNotBlank() } ?: continue
                        val rawNumber = cursor.getString(numberIdx)?.takeIf { it.isNotBlank() } ?: continue
                        val normalized = rawNumber.filter { it.isDigit() || it == '+' }
                        if (normalized.isEmpty() || !seenNumbers.add(normalized)) continue

                        results += ContactInfo(
                            id = cursor.getString(idIdx) ?: normalized,
                            displayName = name,
                            phoneNumber = rawNumber
                        )
                    }
                }
            }

            results
        }
}
