package com.cyberos.nexuslauncher.drawer

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.weight
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.ui.theme.GridLine
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.PanelInkRaised
import com.cyberos.nexuslauncher.ui.theme.TextSecondary

/**
 * Top-level drawer screen: category chips + the arc wheel underneath, backed
 * by a real [InstalledAppsRepository] scan.
 *
 * The scan runs once per composition of this screen (LaunchedEffect(Unit)) —
 * on a real device this takes anywhere from ~50ms to a few hundred ms
 * depending on how many apps are installed, since every icon gets decoded to
 * a bitmap. Milestone-later work: cache the result (DataStore or an in-memory
 * singleton) and only re-scan on PACKAGE_ADDED/PACKAGE_REMOVED broadcasts
 * instead of every time this screen appears.
 */
@Composable
fun AppDrawerScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var allApps by remember { mutableStateOf<List<AppIconData>>(emptyList()) }
    var isLoading by remember { mutableStateOf(true) }
    var selectedCategory by rememberSaveable { mutableStateOf(AppCategory.ALL) }

    LaunchedEffect(Unit) {
        allApps = InstalledAppsRepository.loadLaunchableApps(context.applicationContext)
        isLoading = false
    }

    val filteredApps = remember(allApps, selectedCategory) {
        if (selectedCategory == AppCategory.ALL) {
            allApps
        } else {
            allApps.filter { it.category == selectedCategory }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        CategoryFilterRow(
            selected = selectedCategory,
            onSelect = { selectedCategory = it }
        )

        Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
            when {
                isLoading -> DrawerStatusMessage("Scanning installed apps…")
                filteredApps.isEmpty() -> DrawerStatusMessage("No apps in ${selectedCategory.label}")
                else -> {
                    // key() on the category forces the wheel's internal drag
                    // offset (an Animatable that lives inside ArcWheelDrawer)
                    // to reset to 0 whenever the filtered list changes shape —
                    // without it, switching categories could leave the wheel
                    // pointing at an offset past the end of a shorter list.
                    key(selectedCategory) {
                        ArcWheelDrawer(
                            apps = filteredApps,
                            onAppLaunch = { app ->
                                InstalledAppsRepository.launchApp(context, app.packageName)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DrawerStatusMessage(text: String) {
    Text(
        text = text,
        color = TextSecondary,
        style = MaterialTheme.typography.bodyMedium,
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
    )
}

@Composable
private fun CategoryFilterRow(
    selected: AppCategory,
    onSelect: (AppCategory) -> Unit
) {
    LazyRow(
        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        items(AppCategory.values().toList()) { category ->
            CategoryChip(
                label = category.label,
                isSelected = category == selected,
                onClick = { onSelect(category) }
            )
        }
    }
}

@Composable
private fun CategoryChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .background(
                color = if (isSelected) NeonCyan.copy(alpha = 0.15f) else PanelInkRaised,
                shape = RoundedCornerShape(50)
            )
            .border(
                width = 1.dp,
                color = if (isSelected) NeonCyan else GridLine,
                shape = RoundedCornerShape(50)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = if (isSelected) NeonCyan else TextSecondary,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
