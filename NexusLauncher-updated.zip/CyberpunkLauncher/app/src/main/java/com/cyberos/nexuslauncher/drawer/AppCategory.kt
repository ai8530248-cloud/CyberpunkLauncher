package com.cyberos.nexuslauncher.drawer

import android.content.pm.ApplicationInfo

/**
 * The drawer's filter categories, per the spec (Social / Games / Edit /
 * Video & Music), plus ALL and a catch-all OTHER for anything Android
 * doesn't categorize (most apps predating API 26, or ones that just never
 * declared android:appCategory in their manifest).
 */
enum class AppCategory(val label: String) {
    ALL("All"),
    SOCIAL("Social"),
    GAMES("Games"),
    EDIT("Edit"),
    VIDEO_MUSIC("Video & Music"),
    OTHER("Other");

    companion object {
        /**
         * Maps [ApplicationInfo.category] (the OS-level classification an app
         * declares via android:appCategory) onto our four spec categories.
         * Unset is [ApplicationInfo.CATEGORY_UNDEFINED] (-1) — the overwhelming
         * majority of installed apps in practice, since declaring it is optional.
         */
        fun fromApplicationInfoCategory(categoryInt: Int): AppCategory = when (categoryInt) {
            ApplicationInfo.CATEGORY_GAME -> GAMES
            ApplicationInfo.CATEGORY_SOCIAL -> SOCIAL
            ApplicationInfo.CATEGORY_VIDEO, ApplicationInfo.CATEGORY_AUDIO -> VIDEO_MUSIC
            ApplicationInfo.CATEGORY_IMAGE, ApplicationInfo.CATEGORY_PRODUCTIVITY -> EDIT
            else -> OTHER
        }
    }
}
