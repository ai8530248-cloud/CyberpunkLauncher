package com.cyberos.nexuslauncher.ui.theme

import android.app.Activity
import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.SideEffect
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.core.view.WindowCompat

// The launcher is dark-only by design — a cyberpunk HUD on a light background
// isn't the product. isSystemInDarkTheme() is intentionally not consulted.
private val NexusColorScheme = darkColorScheme(
    primary = NeonCyan,
    onPrimary = VoidBlack,
    secondary = NeonMagenta,
    onSecondary = VoidBlack,
    tertiary = NeonPurple,
    onTertiary = VoidBlack,
    background = VoidBlack,
    onBackground = TextPrimary,
    surface = PanelInk,
    onSurface = TextPrimary,
    surfaceVariant = PanelInkRaised,
    onSurfaceVariant = TextSecondary,
    outline = GridLine,
    error = AlertRed,
    onError = TextPrimary
)

@Composable
fun NexusLauncherTheme(
    content: @Composable () -> Unit
) {
    val colorScheme = NexusColorScheme
    val view = LocalView.current

    if (!view.isInEditMode) {
        SideEffect {
            val window = (view.context as Activity).window
            window.statusBarColor = VoidBlack.toArgb()
            window.navigationBarColor = VoidBlack.toArgb()
            WindowCompat.getInsetsController(window, view).apply {
                isAppearanceLightStatusBars = false
                isAppearanceLightNavigationBars = false
            }
        }
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = NexusTypography,
        shapes = NexusShapes,
        content = content
    )
}
