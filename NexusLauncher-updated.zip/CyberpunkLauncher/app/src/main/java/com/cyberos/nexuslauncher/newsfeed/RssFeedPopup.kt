package com.cyberos.nexuslauncher.newsfeed

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cyberos.nexuslauncher.ui.theme.AlertRed
import com.cyberos.nexuslauncher.ui.theme.GridLine
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.PanelInk
import com.cyberos.nexuslauncher.ui.theme.TextDisabled
import com.cyberos.nexuslauncher.ui.theme.TextPrimary
import com.cyberos.nexuslauncher.ui.theme.TextSecondary
import com.cyberos.nexuslauncher.ui.theme.VoidBlack

private sealed interface FeedLoadState {
    data object Loading : FeedLoadState
    data class Loaded(val items: List<RssItem>) : FeedLoadState
    data class Failed(val message: String) : FeedLoadState
}

@Composable
fun RssFeedPopup(
    onDismiss: () -> Unit,
    feedUrl: String = RssRepository.DEFAULT_FEED_URL
) {
    val context = LocalContext.current
    var loadState by remember { mutableStateOf<FeedLoadState>(FeedLoadState.Loading) }

    LaunchedEffect(feedUrl) {
        loadState = FeedLoadState.Loading
        RssRepository.fetchFeed(feedUrl).fold(
            onSuccess = { loadState = FeedLoadState.Loaded(it) },
            onFailure = { loadState = FeedLoadState.Failed(it.message ?: "Couldn't load feed") }
        )
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .heightIn(max = 480.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(VoidBlack)
                .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "NEWS FEED", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Filled.Close, contentDescription = "Close news feed", tint = TextSecondary)
                    }
                }

                when (val state = loadState) {
                    FeedLoadState.Loading -> Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        CircularProgressIndicator(color = NeonCyan)
                    }

                    is FeedLoadState.Failed -> Text(
                        text = state.message,
                        color = AlertRed,
                        style = MaterialTheme.typography.bodyMedium,
                        modifier = Modifier.padding(16.dp)
                    )

                    is FeedLoadState.Loaded -> LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(10.dp),
                        modifier = Modifier.padding(top = 8.dp)
                    ) {
                        items(state.items, key = { it.link.ifBlank { it.title } }) { item ->
                            NewsItemRow(
                                item = item,
                                onClick = {
                                    if (item.link.isNotBlank()) {
                                        runCatching {
                                            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(item.link)))
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NewsItemRow(item: RssItem, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(PanelInk)
            .border(1.dp, GridLine, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(12.dp)
    ) {
        Text(
            text = item.title,
            color = TextPrimary,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
        if (item.pubDate.isNotBlank()) {
            Text(
                text = item.pubDate,
                color = TextDisabled,
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.padding(top = 4.dp)
            )
        }
    }
}
