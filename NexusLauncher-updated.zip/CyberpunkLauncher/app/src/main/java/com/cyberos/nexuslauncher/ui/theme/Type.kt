package com.cyberos.nexuslauncher.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

// Using Monospace as the stand-in "HUD" face for now — it already reads as
// technical/sci-fi with zero extra resources. Swap in a downloaded Google Font
// (e.g. "Chakra Petch" or "Orbitron") later by replacing HudFontFamily only;
// every style below references it so the change is one line.
val HudFontFamily = FontFamily.Monospace
val BodyFontFamily = FontFamily.SansSerif

val NexusTypography = Typography(
    displayLarge = TextStyle(
        fontFamily = HudFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 57.sp,
        letterSpacing = 1.5.sp
    ),
    // Big HUD clock digits
    displayMedium = TextStyle(
        fontFamily = HudFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 40.sp,
        letterSpacing = 2.sp
    ),
    headlineMedium = TextStyle(
        fontFamily = HudFontFamily,
        fontWeight = FontWeight.SemiBold,
        fontSize = 24.sp,
        letterSpacing = 0.5.sp
    ),
    titleLarge = TextStyle(
        fontFamily = HudFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 18.sp,
        letterSpacing = 0.5.sp
    ),
    bodyLarge = TextStyle(
        fontFamily = BodyFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        letterSpacing = 0.25.sp
    ),
    bodyMedium = TextStyle(
        fontFamily = BodyFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        letterSpacing = 0.2.sp
    ),
    labelSmall = TextStyle(
        fontFamily = HudFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 11.sp,
        letterSpacing = 1.sp
    )
)
