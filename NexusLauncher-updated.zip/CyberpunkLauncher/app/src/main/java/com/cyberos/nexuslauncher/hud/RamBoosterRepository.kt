package com.cyberos.nexuslauncher.hud

import android.app.ActivityManager
import android.app.AppOpsManager
import android.app.usage.UsageStatsManager
import android.content.Context
import android.os.Process
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

data class RamStatus(
    val usedPercent: Int,
    val availableMb: Long,
    val totalMb: Long,
    val isLowMemory: Boolean
)

/** Result of a single boost pass, so the HUD can show what it actually did. */
data class BoostResult(
    val packagesKilled: Int,
    val freedMb: Long
)

/**
 * Real (not decorative) RAM booster backing.
 *
 * Two permissions are already declared in the manifest for this:
 *   - KILL_BACKGROUND_PROCESSES: normal permission, no user prompt needed.
 *   - PACKAGE_USAGE_STATS: special access, must be granted via
 *     Settings > Usage Access — [hasUsageAccess] is how the HUD checks
 *     before offering the real boost vs. sending the user to Settings.
 *
 * Worth knowing going in: since Android 5+, third-party apps can no longer
 * see or kill *arbitrary* background processes (ActivityManager.getRunningAppProcesses
 * only returns your own process now). What every real "RAM booster" app on
 * the Play Store actually does is narrower — use UsageStatsManager (which
 * PACKAGE_USAGE_STATS unlocks) to list recently-used packages, then call
 * killBackgroundProcesses(packageName) on each one individually. That's what
 * this does. It won't touch the current foreground app, this launcher itself,
 * or anything without a usage-stats entry.
 */
object RamBoosterRepository {

    private val EXCLUDED_PACKAGES = setOf(
        "android",
        "com.android.systemui"
    )

    fun currentStatus(context: Context): RamStatus {
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val info = ActivityManager.MemoryInfo()
        am.getMemoryInfo(info)

        val totalMb = info.totalMem / (1024 * 1024)
        val availMb = info.availMem / (1024 * 1024)
        val usedPercent = if (totalMb > 0) {
            (((totalMb - availMb).toFloat() / totalMb) * 100).roundToInt().coerceIn(0, 100)
        } else 0

        return RamStatus(
            usedPercent = usedPercent,
            availableMb = availMb,
            totalMb = totalMb,
            isLowMemory = info.lowMemory
        )
    }

    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = appOps.checkOpNoThrow(
            AppOpsManager.OPSTR_GET_USAGE_STATS,
            Process.myUid(),
            context.packageName
        )
        return mode == AppOpsManager.MODE_ALLOWED
    }

    /**
     * Kills recently-used background packages (last 1h of usage-stats history)
     * and reports how much that actually freed. Returns a zero-effect result
     * if usage access isn't granted rather than throwing — the HUD decides
     * what to show the user for that case.
     */
    suspend fun boost(context: Context): BoostResult = withContext(Dispatchers.IO) {
        if (!hasUsageAccess(context)) return@withContext BoostResult(0, 0)

        val before = currentStatus(context)
        val am = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
        val usageStatsManager = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager

        val end = System.currentTimeMillis()
        val start = end - 60 * 60 * 1000L // last hour
        val recentPackages = usageStatsManager
            .queryUsageStats(UsageStatsManager.INTERVAL_BEST, start, end)
            .orEmpty()
            .filter { it.totalTimeInForeground > 0 }
            .map { it.packageName }
            .distinct()
            .filterNot { it == context.packageName || it in EXCLUDED_PACKAGES }

        recentPackages.forEach { pkg ->
            runCatching { am.killBackgroundProcesses(pkg) }
        }

        val after = currentStatus(context)
        val freedMb = (after.availableMb - before.availableMb).coerceAtLeast(0)

        BoostResult(packagesKilled = recentPackages.size, freedMb = freedMb)
    }
}
