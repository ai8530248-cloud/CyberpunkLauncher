package com.cyberos.nexuslauncher.hud

import android.content.Intent
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.ui.theme.AlertRed
import com.cyberos.nexuslauncher.ui.theme.GridLine
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.NeonGreen
import com.cyberos.nexuslauncher.ui.theme.PanelInk
import com.cyberos.nexuslauncher.ui.theme.PanelInkRaised
import com.cyberos.nexuslauncher.ui.theme.TextSecondary

/**
 * RAM shortcut panel shown under the Orbit ring.
 *
 * [status] is null while the very first read hasn't landed yet. [boostState]
 * drives the button label/behavior; the boost coroutine itself lives in
 * [OrbitHudScreen] since it needs to refresh [status] afterward.
 */
sealed interface BoostUiState {
    data object Idle : BoostUiState
    data object Boosting : BoostUiState
    data class Done(val result: BoostResult) : BoostUiState
}

@Composable
fun RamBoosterPanel(
    status: RamStatus?,
    hasUsageAccess: Boolean,
    boostState: BoostUiState,
    onBoostClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current

    Column(
        modifier = modifier
            .fillMaxWidth()
            .background(PanelInk, RoundedCornerShape(12.dp))
            .border(1.dp, GridLine, RoundedCornerShape(12.dp))
            .padding(16.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = "MEMORY",
                color = TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
            Text(
                text = when {
                    status == null -> "…"
                    else -> "${status.usedPercent}% used · ${status.availableMb} MB free"
                },
                color = if (status?.isLowMemory == true) AlertRed else TextSecondary,
                style = MaterialTheme.typography.labelSmall
            )
        }

        UsageBar(
            usedPercent = status?.usedPercent ?: 0,
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp, bottom = 14.dp)
        )

        when {
            !hasUsageAccess -> BoosterActionRow(
                label = "GRANT USAGE ACCESS",
                labelColor = TextSecondary,
                enabled = true,
                onClick = {
                    context.startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
                }
            )
            boostState is BoostUiState.Boosting -> BoosterActionRow(
                label = "BOOSTING…",
                labelColor = NeonCyan,
                enabled = false,
                onClick = {}
            )
            boostState is BoostUiState.Done -> BoosterActionRow(
                label = if (boostState.result.packagesKilled == 0) {
                    "NOTHING TO CLEAR"
                } else {
                    "FREED ~${boostState.result.freedMb} MB · ${boostState.result.packagesKilled} APPS"
                },
                labelColor = NeonGreen,
                enabled = true,
                onClick = onBoostClick
            )
            else -> BoosterActionRow(
                label = "BOOST",
                labelColor = NeonCyan,
                enabled = true,
                onClick = onBoostClick
            )
        }
    }
}

@Composable
private fun UsageBar(usedPercent: Int, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .height(6.dp)
            .background(PanelInkRaised, RoundedCornerShape(50))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth(usedPercent.coerceIn(0, 100) / 100f)
                .height(6.dp)
                .background(
                    if (usedPercent >= 85) AlertRed else NeonCyan,
                    RoundedCornerShape(50)
                )
        )
    }
}

@Composable
private fun BoosterActionRow(
    label: String,
    labelColor: androidx.compose.ui.graphics.Color,
    enabled: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .background(PanelInkRaised, RoundedCornerShape(8.dp))
            .border(1.dp, GridLine, RoundedCornerShape(8.dp))
            .then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            color = labelColor,
            style = MaterialTheme.typography.titleLarge
        )
    }
}
