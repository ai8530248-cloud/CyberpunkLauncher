package com.cyberos.nexuslauncher.security

import android.accessibilityservice.AccessibilityService
import android.os.Build
import android.util.Log
import android.view.accessibility.AccessibilityEvent

/**
 * Holds no state about the screen and does no gesture detection — see
 * res/xml/lock_accessibility_service_config.xml for why. Its only purpose is
 * to exist as a *connected* AccessibilityService so [lockScreen] has
 * something to call [performGlobalAction] on. GLOBAL_ACTION_LOCK_SCREEN was
 * added in API 28; below that, there's no non-device-admin way to lock the
 * screen programmatically, so [lockScreen] just returns false there.
 *
 * [instance] is a plain nullable companion var, not a singleton object,
 * because the system — not us — controls this service's lifecycle: it can
 * be unbound at any time (user revokes access in Settings), and we need
 * [requestLock] to fail safely rather than hold a stale reference.
 */
class LockAccessibilityService : AccessibilityService() {

    companion object {
        private const val TAG = "LockAccessibilityService"

        private var instance: LockAccessibilityService? = null

        val isConnected: Boolean
            get() = instance != null

        /** Returns true if the lock actually fired. */
        fun requestLock(): Boolean {
            val service = instance ?: return false
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.P) return false
            return service.performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        Log.d(TAG, "Lock gesture service connected")
    }

    override fun onUnbind(intent: android.content.Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onInterrupt() {
        // Nothing to interrupt — this service performs no ongoing work.
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Intentionally unhandled. The manifest config still requires an
        // eventTypes value, but we don't act on any of them here.
    }
}
