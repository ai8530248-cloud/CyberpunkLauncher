package com.cyberos.nexuslauncher.voice

import android.content.Context
import android.content.Intent
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.platform.LocalContext
import com.cyberos.nexuslauncher.drawer.AppIconData
import com.cyberos.nexuslauncher.drawer.InstalledAppsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

/**
 * What the mic UI renders. [Listening.amplitude] is normalized 0f..1f
 * (raw onRmsChanged dB values are unbounded and mostly meaningless without
 * calibration per-device, so the controller does that clamping once here
 * rather than pushing raw dB out to every consumer).
 */
sealed interface VoiceUiState {
    data object Idle : VoiceUiState
    data class Listening(val amplitude: Float) : VoiceUiState
    data object Processing : VoiceUiState
    data class Result(val outcome: VoiceExecutionOutcome) : VoiceUiState
    data object Unavailable : VoiceUiState
    data class Error(val message: String) : VoiceUiState
}

/**
 * Owns one [SpeechRecognizer] instance. SpeechRecognizer is strictly
 * main-thread — created on it, and every RecognitionListener callback
 * arrives back on it — so this class assumes it's constructed and driven
 * from the main thread, which [rememberVoiceAssistantController] guarantees.
 *
 * The installed-apps list is loaded once, lazily, on the first listening
 * session rather than eagerly at construction — most sessions will be
 * "boost ram" or "lock screen", which don't need it at all.
 */
class VoiceAssistantController(
    private val context: Context,
    private val scope: CoroutineScope
) {
    private val _state = MutableStateFlow<VoiceUiState>(VoiceUiState.Idle)
    val state: StateFlow<VoiceUiState> = _state.asStateFlow()

    private var recognizer: SpeechRecognizer? = null
    private var installedApps: List<AppIconData>? = null
    private var resultResetJob: Job? = null

    fun startListening() {
        if (!SpeechRecognizer.isRecognitionAvailable(context)) {
            _state.value = VoiceUiState.Unavailable
            return
        }
        if (_state.value is VoiceUiState.Listening) return // already going

        resultResetJob?.cancel()
        ensureAppsLoaded()

        val speechRecognizer = recognizer ?: SpeechRecognizer.createSpeechRecognizer(context).also {
            it.setRecognitionListener(listener)
            recognizer = it
        }

        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(
                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
            )
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
        }

        _state.value = VoiceUiState.Listening(amplitude = 0f)
        speechRecognizer.startListening(intent)
    }

    fun stopListening() {
        recognizer?.stopListening()
    }

    /** Call from onDispose — releases the recognizer entirely, not just stops it. */
    fun destroy() {
        resultResetJob?.cancel()
        recognizer?.let {
            it.setRecognitionListener(null)
            it.destroy()
        }
        recognizer = null
        _state.value = VoiceUiState.Idle
    }

    private fun ensureAppsLoaded() {
        if (installedApps != null) return
        scope.launch {
            installedApps = InstalledAppsRepository.loadLaunchableApps(context)
        }
    }

    private fun handleFinalTranscript(rawText: String) {
        _state.value = VoiceUiState.Processing
        scope.launch {
            // The lazy load above is fire-and-forget from startListening(), so
            // if the user spoke fast it may not have landed yet — wait for it
            // here rather than executing "open X" against an empty list.
            val apps = installedApps ?: InstalledAppsRepository.loadLaunchableApps(context)
                .also { installedApps = it }

            val command = VoiceCommandParser.parse(rawText)
            val outcome = VoiceCommandExecutor.execute(context, command, apps)
            _state.value = VoiceUiState.Result(outcome)

            // Auto-return to Idle so the orb doesn't sit on a stale result
            // forever if the user doesn't tap it again.
            resultResetJob = launch {
                delay(2500)
                if (_state.value is VoiceUiState.Result) {
                    _state.value = VoiceUiState.Idle
                }
            }
        }
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: android.os.Bundle?) {
            _state.value = VoiceUiState.Listening(amplitude = 0f)
        }

        override fun onBeginningOfSpeech() = Unit

        override fun onRmsChanged(rmsdB: Float) {
            // Typical mic RMS range is roughly -2..10 dB in this API; clamp
            // and normalize so the UI never has to think in decibels.
            val normalized = ((rmsdB + 2f) / 12f).coerceIn(0f, 1f)
            val current = _state.value
            if (current is VoiceUiState.Listening) {
                _state.value = VoiceUiState.Listening(amplitude = normalized)
            }
        }

        override fun onBufferReceived(buffer: ByteArray?) = Unit

        override fun onEndOfSpeech() {
            _state.value = VoiceUiState.Processing
        }

        override fun onError(error: Int) {
            // NO_MATCH / SPEECH_TIMEOUT just means "heard nothing usable" —
            // that's a normal outcome for a HUD mic, not a real error to
            // surface as a scary message.
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    _state.value = VoiceUiState.Result(
                        VoiceExecutionOutcome.NotUnderstood(raw = "")
                    )
                    resultResetJob = scope.launch {
                        delay(2000)
                        if (_state.value is VoiceUiState.Result) {
                            _state.value = VoiceUiState.Idle
                        }
                    }
                }
                else -> _state.value = VoiceUiState.Error(errorMessage(error))
            }
        }

        override fun onResults(results: android.os.Bundle?) {
            val text = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                ?.firstOrNull()
            if (text.isNullOrBlank()) {
                _state.value = VoiceUiState.Result(VoiceExecutionOutcome.NotUnderstood(raw = ""))
            } else {
                handleFinalTranscript(text)
            }
        }

        override fun onPartialResults(partialResults: android.os.Bundle?) = Unit
        override fun onEvent(eventType: Int, params: android.os.Bundle?) = Unit
    }

    private fun errorMessage(error: Int): String = when (error) {
        SpeechRecognizer.ERROR_AUDIO -> "Microphone error"
        SpeechRecognizer.ERROR_CLIENT -> "Voice recognition error"
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission needed"
        SpeechRecognizer.ERROR_NETWORK -> "Network error"
        SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Network timeout"
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "Recognizer busy, try again"
        SpeechRecognizer.ERROR_SERVER -> "Server error"
        else -> "Voice recognition error"
    }
}

/**
 * Creates a [VoiceAssistantController] scoped to this composition — destroys
 * the underlying [SpeechRecognizer] in onDispose so it's never leaked across
 * navigation or process changes. The coroutine scope is Compose's own
 * [rememberCoroutineScope], which is already cancelled automatically when
 * this leaves composition — no separate Job/cancel bookkeeping needed here.
 */
@Composable
fun rememberVoiceAssistantController(): VoiceAssistantController {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val controller = remember { VoiceAssistantController(context, scope) }

    DisposableEffect(controller) {
        onDispose { controller.destroy() }
    }

    return controller
}
