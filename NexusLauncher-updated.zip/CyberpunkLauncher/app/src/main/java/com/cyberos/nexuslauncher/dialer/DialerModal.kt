package com.cyberos.nexuslauncher.dialer

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.cyberos.nexuslauncher.ui.theme.GridLine
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.NeonGreen
import com.cyberos.nexuslauncher.ui.theme.PanelInk
import com.cyberos.nexuslauncher.ui.theme.PanelInkRaised
import com.cyberos.nexuslauncher.ui.theme.TextDisabled
import com.cyberos.nexuslauncher.ui.theme.TextPrimary
import com.cyberos.nexuslauncher.ui.theme.TextSecondary
import com.cyberos.nexuslauncher.ui.theme.VoidBlack
import com.google.accompanist.permissions.ExperimentalPermissionsApi

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun DialerModal(onDismiss: () -> Unit) {
    val context = LocalContext.current
    val permissionsState = rememberDialerPermissionsState()

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(20.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(VoidBlack)
                .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
                .padding(20.dp)
        ) {
            if (permissionsState.allPermissionsGranted) {
                DialerContent(context = context, onDismiss = onDismiss)
            } else {
                DialerPermissionPrompt(onGrantClick = { permissionsState.launchMultiplePermissionRequest() })
            }
        }
    }
}

@Composable
private fun DialerPermissionPrompt(onGrantClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp)
    ) {
        Icon(
            imageVector = Icons.Filled.Call,
            contentDescription = null,
            tint = TextDisabled,
            modifier = Modifier.size(48.dp)
        )
        Text(
            text = "Dialer needs phone and contacts access",
            color = TextSecondary,
            style = MaterialTheme.typography.bodyMedium,
            modifier = Modifier.padding(top = 12.dp, bottom = 16.dp)
        )
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(8.dp))
                .background(PanelInkRaised)
                .border(1.dp, GridLine, RoundedCornerShape(8.dp))
                .clickable(onClick = onGrantClick)
                .padding(horizontal = 20.dp, vertical = 10.dp)
        ) {
            Text(text = "GRANT ACCESS", color = NeonCyan, style = MaterialTheme.typography.titleLarge)
        }
    }
}

@Composable
private fun DialerContent(context: Context, onDismiss: () -> Unit) {
    var dialedNumber by remember { mutableStateOf("") }
    var contacts by remember { mutableStateOf<List<ContactInfo>>(emptyList()) }
    var simAccounts by remember { mutableStateOf<List<SimAccount>>(emptyList()) }
    var selectedSim by remember { mutableStateOf<SimAccount?>(null) }

    LaunchedEffect(Unit) {
        contacts = ContactsRepository.loadContactsWithNumbers(context)
        val accounts = TelecomCallRepository.listCallCapableAccounts(context)
        simAccounts = accounts
        selectedSim = accounts.firstOrNull()
    }

    Column(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = "DIALER", color = TextSecondary, style = MaterialTheme.typography.labelSmall)
            IconButton(onClick = onDismiss) {
                Icon(imageVector = Icons.Filled.Close, contentDescription = "Close dialer", tint = TextSecondary)
            }
        }

        Text(
            text = dialedNumber.ifEmpty { " " },
            color = TextPrimary,
            style = MaterialTheme.typography.displayMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 16.dp)
        )

        if (contacts.isNotEmpty()) {
            Text(text = "CONTACTS", color = TextDisabled, style = MaterialTheme.typography.labelSmall)
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
            ) {
                items(contacts, key = { it.id }) { contact ->
                    ContactChip(contact = contact, onClick = { dialedNumber = contact.phoneNumber })
                }
            }
        }

        DialerKeypad(
            onDigit = { digit -> dialedNumber += digit },
            onBackspace = { if (dialedNumber.isNotEmpty()) dialedNumber = dialedNumber.dropLast(1) },
            modifier = Modifier.padding(vertical = 12.dp)
        )

        if (simAccounts.size > 1) {
            Text(text = "SIM", color = TextDisabled, style = MaterialTheme.typography.labelSmall)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 12.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                simAccounts.forEach { account ->
                    SimButton(
                        account = account,
                        selected = account == selectedSim,
                        onClick = { selectedSim = account }
                    )
                }
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            val canCall = dialedNumber.isNotEmpty()
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(if (canCall) NeonGreen else PanelInkRaised)
                    .clickable(enabled = canCall) {
                        TelecomCallRepository.placeCall(context, dialedNumber, selectedSim)
                        onDismiss()
                    },
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Filled.Call,
                    contentDescription = "Call",
                    tint = if (canCall) VoidBlack else TextDisabled
                )
            }
        }
    }
}

@Composable
private fun ContactChip(contact: ContactInfo, onClick: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clip(RoundedCornerShape(10.dp))
            .background(PanelInk)
            .border(1.dp, GridLine, RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
            .padding(10.dp)
    ) {
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(PanelInkRaised),
            contentAlignment = Alignment.Center
        ) {
            Icon(imageVector = Icons.Filled.Person, contentDescription = null, tint = NeonCyan)
        }
        Text(
            text = contact.displayName,
            color = TextPrimary,
            style = MaterialTheme.typography.labelSmall,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .padding(top = 4.dp)
                .size(width = 56.dp, height = 14.dp)
        )
    }
}

@Composable
private fun SimButton(account: SimAccount, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(if (selected) NeonCyan.copy(alpha = 0.15f) else PanelInkRaised)
            .border(1.dp, if (selected) NeonCyan else GridLine, RoundedCornerShape(8.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(
            text = account.label,
            color = if (selected) NeonCyan else TextSecondary,
            style = MaterialTheme.typography.labelSmall
        )
    }
}
