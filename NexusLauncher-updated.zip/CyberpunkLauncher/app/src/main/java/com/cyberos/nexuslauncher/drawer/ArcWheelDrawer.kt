package com.cyberos.nexuslauncher.drawer

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.Image
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.PanelInkRaised
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

data class AppIconData(
    val packageName: String,
    val label: String,
    val icon: ImageBitmap,
    val category: AppCategory
)

/**
 * Circular ("arc wheel") app drawer.
 *
 * The math mirrors the interactive prototype validated before this file was
 * written: each icon's angle is its distance from the centered index; that
 * angle drives both its position on a circle pivoted off-screen and its
 * scale/opacity falloff (see the per-icon calculation inside the layout body
 * below). Changing radius/angleStep should be done by feel, not by
 * re-deriving the trig each time.
 *
 * Deliberately bounded (0..apps.size-1), not wrap-around — a finite drawer
 * reads clearer than an infinite wheel here. Swap the coerceIn for a modulo
 * if an infinite loop is wanted later.
 *
 * @param apps the full list, in wheel order.
 * @param onAppLaunch called when a settled (non-drag) tap lands on an icon.
 */
@Composable
fun ArcWheelDrawer(
    apps: List<AppIconData>,
    onAppLaunch: (AppIconData) -> Unit,
    modifier: Modifier = Modifier
) {
    if (apps.isEmpty()) return

    val density = LocalDensity.current
    val scope = rememberCoroutineScope()

    // Radians per index step, and drag pixels needed to advance one index —
    // both tuned to match the prototype's feel (46px per index at 1x density).
    val angleStep = 0.46f
    val pxPerIndex = with(density) { 46.dp.toPx() }

    val offset = remember { Animatable(0f) }
    var isDragging by remember { mutableStateOf(false) }

    val draggableState = rememberDraggableState { deltaPx ->
        scope.launch {
            offset.snapTo(offset.value - deltaPx / pxPerIndex)
        }
    }

    BoxWithConstraints(
        modifier = modifier
            .fillMaxSize()
            .draggable(
                state = draggableState,
                orientation = Orientation.Vertical,
                onDragStarted = { isDragging = true },
                onDragStopped = { velocityPxPerSec ->
                    isDragging = false
                    val projectedOffset = offset.value - (velocityPxPerSec / 1000f) * 3.5f / pxPerIndex
                    val targetIndex = projectedOffset.roundToInt()
                        .coerceIn(0, apps.size - 1)
                    scope.launch {
                        offset.animateTo(
                            targetValue = targetIndex.toFloat(),
                            animationSpec = tween(durationMillis = 380)
                        )
                    }
                }
            )
    ) {
        val widthPx = with(density) { maxWidth.toPx() }
        val heightPx = with(density) { maxHeight.toPx() }
        val pivotX = widthPx - with(density) { 30.dp.toPx() }
        val pivotY = heightPx / 2f
        val radius = with(density) { 150.dp.toPx() }
        val iconSizePx = with(density) { 56.dp.toPx() }

        apps.forEachIndexed { index, app ->
            val angle = (index - offset.value) * angleStep
            if (abs(angle) > 1.7f) return@forEachIndexed // culled — off the visible arc

            val x = pivotX - radius * cos(angle)
            val y = pivotY + radius * sin(angle)
            val scale = 0.55f + 0.45f * cos(angle)
            val alpha = (cos(angle) + 0.35f).coerceIn(0f, 1f)
            val isCentered = abs(angle) < 0.1f

            ArcWheelIcon(
                app = app,
                xPx = x - iconSizePx / 2f,
                yPx = y - iconSizePx / 2f,
                scale = scale,
                alpha = alpha,
                highlighted = isCentered,
                onTap = {
                    if (!isDragging) {
                        scope.launch {
                            offset.animateTo(index.toFloat(), tween(280))
                        }
                        onAppLaunch(app)
                    }
                }
            )
        }
    }
}

@Composable
private fun ArcWheelIcon(
    app: AppIconData,
    xPx: Float,
    yPx: Float,
    scale: Float,
    alpha: Float,
    highlighted: Boolean,
    onTap: () -> Unit
) {
    val density = LocalDensity.current
    val xDp = with(density) { xPx.toDp() }
    val yDp = with(density) { yPx.toDp() }
    val interactionSource = remember { MutableInteractionSource() }

    Box(
        modifier = Modifier
            .offset(x = xDp, y = yDp)
            .size(56.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
                this.alpha = alpha
            }
            .background(PanelInkRaised, CircleShape)
            .border(
                BorderStroke(1.dp, if (highlighted) NeonCyan else Color.Transparent),
                CircleShape
            )
            .clickable(
                interactionSource = interactionSource,
                indication = null,
                onClick = onTap
            ),
        contentAlignment = Alignment.Center
    ) {
        Image(
            bitmap = app.icon,
            contentDescription = app.label,
            modifier = Modifier.size(40.dp)
        )
    }
}
