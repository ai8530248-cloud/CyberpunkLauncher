package com.cyberos.nexuslauncher.voice

import java.util.Locale

/**
 * The fixed command set from the spec. [OpenApp] carries the raw spoken app
 * name (not yet matched against installed apps — that's [VoiceCommandExecutor]'s
 * job, since matching needs the installed-apps list and this parser doesn't).
 */
sealed interface VoiceCommand {
    data class OpenApp(val query: String) : VoiceCommand
    data object BoostRam : VoiceCommand
    data object LockScreen : VoiceCommand
    data class Unrecognized(val raw: String) : VoiceCommand
}

/**
 * Plain keyword/regex matching, not a real NLU model — the spec's command
 * set is fixed and small enough that a phrase list is more predictable and
 * debuggable than pulling in on-device NLU for three intents.
 */
object VoiceCommandParser {

    private val OPEN_PATTERN = Regex("^(?:open|launch|start)\\s+(.+)$", RegexOption.IGNORE_CASE)

    private val LOCK_PHRASES = listOf(
        "lock screen", "lock the screen", "lock my screen", "lock phone", "lock",
        "screen off", "turn off screen", "turn off the screen"
    )

    private val BOOST_PHRASES = listOf(
        "boost ram", "boost the ram", "boost memory", "clean", "clean ram",
        "clean memory", "clear ram", "clear memory", "free up memory",
        "free up ram", "optimize memory", "speed up my phone", "speed up phone"
    )

    fun parse(rawText: String): VoiceCommand {
        val normalized = rawText.trim().lowercase(Locale.getDefault())
        if (normalized.isEmpty()) return VoiceCommand.Unrecognized(rawText)

        // Checked before the "open" pattern so phrases like "lock screen"
        // never get misread as an attempt to open an app named "screen".
        if (LOCK_PHRASES.any { normalized == it || normalized.contains(it) }) {
            return VoiceCommand.LockScreen
        }
        if (BOOST_PHRASES.any { normalized == it || normalized.contains(it) }) {
            return VoiceCommand.BoostRam
        }

        OPEN_PATTERN.find(normalized)?.let { match ->
            val query = match.groupValues[1].trim()
            if (query.isNotEmpty()) return VoiceCommand.OpenApp(query)
        }

        return VoiceCommand.Unrecognized(rawText)
    }
}
