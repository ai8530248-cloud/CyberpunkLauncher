package com.cyberos.nexuslauncher.voice

import android.content.Context
import com.cyberos.nexuslauncher.drawer.AppIconData
import com.cyberos.nexuslauncher.drawer.InstalledAppsRepository
import com.cyberos.nexuslauncher.hud.RamBoosterRepository
import com.cyberos.nexuslauncher.security.AccessibilityLockRepository
import java.util.Locale

/** What actually happened, so the UI can show a real result, not just "done". */
sealed interface VoiceExecutionOutcome {
    data class OpenedApp(val label: String) : VoiceExecutionOutcome
    data class AppNotFound(val query: String) : VoiceExecutionOutcome
    data class Boosted(val freedMb: Long, val packagesKilled: Int) : VoiceExecutionOutcome
    data object BoostNeedsUsageAccess : VoiceExecutionOutcome
    data object Locked : VoiceExecutionOutcome
    data object LockUnavailable : VoiceExecutionOutcome
    data class NotUnderstood(val raw: String) : VoiceExecutionOutcome
}

/**
 * Deliberately has no state of its own — every dependency it calls
 * ([InstalledAppsRepository], [RamBoosterRepository], [AccessibilityLockRepository])
 * already exists from earlier milestones, so this is just the intent→action
 * mapping, not a new source of truth for apps/RAM/lock status.
 */
object VoiceCommandExecutor {

    suspend fun execute(
        context: Context,
        command: VoiceCommand,
        installedApps: List<AppIconData>
    ): VoiceExecutionOutcome = when (command) {
        is VoiceCommand.OpenApp -> {
            val match = findBestMatch(command.query, installedApps)
            if (match != null) {
                InstalledAppsRepository.launchApp(context, match.packageName)
                VoiceExecutionOutcome.OpenedApp(match.label)
            } else {
                VoiceExecutionOutcome.AppNotFound(command.query)
            }
        }

        VoiceCommand.BoostRam -> {
            if (!RamBoosterRepository.hasUsageAccess(context)) {
                VoiceExecutionOutcome.BoostNeedsUsageAccess
            } else {
                val result = RamBoosterRepository.boost(context)
                VoiceExecutionOutcome.Boosted(result.freedMb, result.packagesKilled)
            }
        }

        VoiceCommand.LockScreen -> {
            if (AccessibilityLockRepository.requestLock()) {
                VoiceExecutionOutcome.Locked
            } else {
                VoiceExecutionOutcome.LockUnavailable
            }
        }

        is VoiceCommand.Unrecognized -> VoiceExecutionOutcome.NotUnderstood(command.raw)
    }

    /**
     * Three-tier fallback, cheapest match first: exact label, then
     * starts-with, then contains. Covers "open camera", "open google maps",
     * and "open chrome" (matching "Google Chrome") without a string-distance
     * library for a set this small.
     */
    private fun findBestMatch(query: String, apps: List<AppIconData>): AppIconData? {
        val normalizedQuery = query.trim().lowercase(Locale.getDefault())
        if (normalizedQuery.isEmpty()) return null

        apps.firstOrNull { it.label.lowercase(Locale.getDefault()) == normalizedQuery }
            ?.let { return it }
        apps.firstOrNull { it.label.lowercase(Locale.getDefault()).startsWith(normalizedQuery) }
            ?.let { return it }
        apps.firstOrNull { it.label.lowercase(Locale.getDefault()).contains(normalizedQuery) }
            ?.let { return it }
        return null
    }
}
