package com.cyberos.nexuslauncher.voice

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.ui.theme.AlertRed
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.NeonGreen
import com.cyberos.nexuslauncher.ui.theme.NeonMagenta
import com.cyberos.nexuslauncher.ui.theme.PanelInkRaised
import com.cyberos.nexuslauncher.ui.theme.TextDisabled
import com.cyberos.nexuslauncher.ui.theme.TextSecondary

private val ORB_DIAMETER = 72.dp
private val RIPPLE_MAX_DIAMETER = 120.dp

/**
 * Self-contained mic component: orb + ripple animation + status line. Tap
 * toggles listening. Doesn't know about permissions — the caller wraps this
 * in [VoiceAssistantPermissionGate] so this component only ever renders once
 * RECORD_AUDIO is actually granted.
 */
@Composable
fun VoiceMicOrb(
    state: VoiceUiState,
    onStartListening: () -> Unit,
    onStopListening: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.size(RIPPLE_MAX_DIAMETER)
        ) {
            if (state is VoiceUiState.Listening) {
                ListeningRipples(amplitude = state.amplitude)
            } else if (state is VoiceUiState.Processing) {
                ProcessingRing()
            }

            MicButton(
                state = state,
                onClick = {
                    when (state) {
                        is VoiceUiState.Listening -> onStopListening()
                        else -> onStartListening()
                    }
                }
            )
        }

        StatusLine(state = state)
    }
}

@Composable
private fun MicButton(state: VoiceUiState, onClick: () -> Unit) {
    val glowColor = when (state) {
        is VoiceUiState.Listening -> NeonCyan
        is VoiceUiState.Processing -> NeonMagenta
        is VoiceUiState.Error -> AlertRed
        VoiceUiState.Unavailable -> TextDisabled
        else -> NeonCyan.copy(alpha = 0.7f)
    }

    // Slow idle pulse so the orb never looks static/dead when not listening.
    val infinite = rememberInfiniteTransition(label = "mic_idle_pulse")
    val idlePulse by infinite.animateFloat(
        initialValue = 0.6f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1400, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "mic_idle_pulse_value"
    )
    val glowAlpha = if (state is VoiceUiState.Listening || state is VoiceUiState.Processing) 1f else idlePulse

    Box(
        modifier = Modifier
            .size(ORB_DIAMETER)
            .clip(CircleShape)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null,
                enabled = state != VoiceUiState.Unavailable,
                onClick = onClick
            )
            .drawBehindGlow(glowColor, glowAlpha),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = if (state == VoiceUiState.Unavailable) Icons.Filled.MicOff else Icons.Filled.Mic,
            contentDescription = if (state is VoiceUiState.Listening) {
                "Stop voice command"
            } else {
                "Start voice command"
            },
            tint = Color.White,
            modifier = Modifier.size(28.dp)
        )
    }
}

private fun Modifier.drawBehindGlow(color: Color, alpha: Float): Modifier = this.then(
    Modifier.background(
        brush = Brush.radialGradient(
            colors = listOf(
                color.copy(alpha = alpha),
                color.copy(alpha = alpha * 0.6f),
                PanelInkRaised
            )
        )
    )
)

@Composable
private fun ListeningRipples(amplitude: Float) {
    val infinite = rememberInfiniteTransition(label = "mic_ripple")
    // Two rings, offset in phase, so there's always at least one ring
    // mid-expansion — a single ring reads as a blip, two reads as "alive".
    val ripple1 by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(1200, easing = LinearEasing)),
        label = "ripple1"
    )
    val ripple2 by infinite.animateFloat(
        initialValue = 0f, targetValue = 1f,
        animationSpec = infiniteRepeatable(
            tween(1200, easing = LinearEasing),
            initialStartOffset = androidx.compose.animation.core.StartOffset(600)
        ),
        label = "ripple2"
    )

    Canvas(modifier = Modifier.size(RIPPLE_MAX_DIAMETER)) {
        val maxRadius = size.minDimension / 2f
        val baseRadius = maxRadius * 0.32f // orb's own radius, ripples start just outside it
        // Louder speech pushes the ripple radius out further, so the ring
        // visibly reacts to voice instead of animating identically in silence.
        val amplitudeBoost = 1f + (amplitude * 0.35f)

        listOf(ripple1, ripple2).forEach { progress ->
            val radius = (baseRadius + (maxRadius - baseRadius) * progress) * amplitudeBoost
            drawCircle(
                color = NeonCyan.copy(alpha = (1f - progress) * 0.5f),
                radius = radius.coerceAtMost(maxRadius),
                center = Offset(size.width / 2f, size.height / 2f),
                style = Stroke(width = 2.5.dp.toPx())
            )
        }
    }
}

@Composable
private fun ProcessingRing() {
    val infinite = rememberInfiniteTransition(label = "mic_processing")
    val rotation by infinite.animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing)),
        label = "processing_rotation"
    )
    Canvas(modifier = Modifier.size(RIPPLE_MAX_DIAMETER)) {
        val strokePx = 3.dp.toPx()
        val radius = size.minDimension / 2f * 0.42f
        drawArc(
            color = NeonMagenta,
            startAngle = rotation,
            sweepAngle = 90f,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = strokePx)
        )
    }
}

@Composable
private fun StatusLine(state: VoiceUiState) {
    val (text, color) = when (state) {
        VoiceUiState.Idle -> "Tap to speak" to TextDisabled
        is VoiceUiState.Listening -> "Listening…" to NeonCyan
        VoiceUiState.Processing -> "Thinking…" to NeonMagenta
        VoiceUiState.Unavailable -> "Voice input unavailable on this device" to TextDisabled
        is VoiceUiState.Error -> state.message to AlertRed
        is VoiceUiState.Result -> outcomeLabel(state.outcome)
    }

    Text(
        text = text,
        color = color,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.padding(top = 8.dp)
    )
}

private fun outcomeLabel(outcome: VoiceExecutionOutcome): Pair<String, Color> = when (outcome) {
    is VoiceExecutionOutcome.OpenedApp -> "Opening ${outcome.label}" to NeonGreen
    is VoiceExecutionOutcome.AppNotFound -> "Couldn't find \"${outcome.query}\"" to AlertRed
    is VoiceExecutionOutcome.Boosted -> "Freed ~${outcome.freedMb} MB · ${outcome.packagesKilled} apps" to NeonGreen
    VoiceExecutionOutcome.BoostNeedsUsageAccess -> "Enable Usage Access to boost RAM" to TextSecondary
    VoiceExecutionOutcome.Locked -> "Locking…" to NeonGreen
    VoiceExecutionOutcome.LockUnavailable -> "Enable the lock gesture in Settings first" to TextSecondary
    is VoiceExecutionOutcome.NotUnderstood -> "Didn't catch that — try again" to TextSecondary
}
