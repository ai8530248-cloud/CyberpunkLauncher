package com.cyberos.nexuslauncher.newsfeed

import android.util.Xml
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.xmlpull.v1.XmlPullParser
import java.io.Reader
import java.net.HttpURLConnection
import java.net.URL

data class RssItem(
    val title: String,
    val link: String,
    val pubDate: String,
    val description: String
)

/**
 * Real RSS 2.0 parsing via android.util.Xml's built-in pull parser — no
 * extra XML dependency needed for a feed this flat (title/link/pubDate/
 * description directly under each <item>, no nesting to speak of).
 *
 * DEFAULT_FEED_URL points at BBC News's public RSS feed: a real, working
 * default rather than a fake placeholder, since the requirements didn't
 * specify a source. Swap it for whatever feed you actually want to show —
 * nothing else here needs to change, [fetchFeed] takes the URL as a parameter.
 */
object RssRepository {
    const val DEFAULT_FEED_URL = "https://feeds.bbci.co.uk/news/rss.xml"

    suspend fun fetchFeed(feedUrl: String = DEFAULT_FEED_URL): Result<List<RssItem>> =
        withContext(Dispatchers.IO) {
            runCatching {
                val connection = URL(feedUrl).openConnection() as HttpURLConnection
                connection.connectTimeout = 8000
                connection.readTimeout = 8000
                connection.requestMethod = "GET"
                try {
                    connection.inputStream.bufferedReader().use { reader ->
                        parseRss(reader)
                    }
                } finally {
                    connection.disconnect()
                }
            }
        }

    private fun parseRss(reader: Reader): List<RssItem> {
        val parser: XmlPullParser = Xml.newPullParser()
        parser.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        parser.setInput(reader)

        val items = mutableListOf<RssItem>()
        var inItem = false
        var title = ""
        var link = ""
        var pubDate = ""
        var description = ""

        var eventType = parser.eventType
        while (eventType != XmlPullParser.END_DOCUMENT) {
            when (eventType) {
                XmlPullParser.START_TAG -> when (parser.name) {
                    "item" -> {
                        inItem = true
                        title = ""; link = ""; pubDate = ""; description = ""
                    }
                    "title" -> if (inItem) title = parser.nextTextSafe()
                    "link" -> if (inItem) link = parser.nextTextSafe()
                    "pubDate" -> if (inItem) pubDate = parser.nextTextSafe()
                    "description" -> if (inItem) description = parser.nextTextSafe()
                }
                XmlPullParser.END_TAG -> if (parser.name == "item") {
                    inItem = false
                    if (title.isNotBlank()) {
                        items += RssItem(title = title, link = link, pubDate = pubDate, description = description)
                    }
                }
            }
            eventType = parser.next()
        }
        return items
    }

    /** nextText() throws if the current tag isn't purely text (e.g. has nested markup) — guard malformed/odd feeds. */
    private fun XmlPullParser.nextTextSafe(): String = runCatching { nextText().trim() }.getOrDefault("")
}
