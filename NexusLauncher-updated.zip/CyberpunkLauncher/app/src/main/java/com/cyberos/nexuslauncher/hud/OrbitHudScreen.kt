package com.cyberos.nexuslauncher.hud

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Newspaper
import androidx.compose.material.icons.filled.RocketLaunch
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.dialer.DialerModal
import com.cyberos.nexuslauncher.newsfeed.RssFeedPopup
import com.cyberos.nexuslauncher.security.AccessibilityLockRepository
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.TextPrimary
import com.cyberos.nexuslauncher.ui.theme.TextDisabled
import com.cyberos.nexuslauncher.ui.theme.TextSecondary
import com.cyberos.nexuslauncher.voice.VoiceAssistantEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

private val TIME_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("hh:mm a")
private val DATE_FORMAT: DateTimeFormatter = DateTimeFormatter.ofPattern("EEE, MMM d")

/**
 * Root HUD screen — clock + weather ring + RAM booster shortcuts.
 *
 * This is the screen [MainActivity]'s TODO refers to as "the real home
 * screen" that the app drawer will eventually open on top of via swipe-up;
 * that wiring is the next milestone, not this one.
 *
 * State ownership: the clock ticks locally (cheap, no repository needed).
 * Weather is fetched once per composition — same one-shot pattern
 * [AppDrawerScreen] uses for its app scan. RAM status is re-read on a timer
 * *and* immediately after a boost, since that's the number the boost is
 * supposed to move.
 */
@Composable
fun OrbitHudScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var now by remember { mutableStateOf(LocalDateTime.now()) }
    var weather by remember { mutableStateOf<WeatherSnapshot?>(null) }
    var ramStatus by remember { mutableStateOf<RamStatus?>(null) }
    var hasUsageAccess by remember { mutableStateOf(RamBoosterRepository.hasUsageAccess(context)) }
    var boostState by remember { mutableStateOf<BoostUiState>(BoostUiState.Idle) }
    var hasLockGestureEnabled by remember {
        mutableStateOf(AccessibilityLockRepository.isServiceEnabled(context))
    }
    var showDialer by remember { mutableStateOf(false) }
    var showNewsFeed by remember { mutableStateOf(false) }

    // Clock: tick every second, drift-free enough for a HUD (not a stopwatch).
    LaunchedEffect(Unit) {
        while (true) {
            now = LocalDateTime.now()
            delay(1000)
        }
    }

    // Weather: one-shot fetch, mirrors AppDrawerScreen's scan pattern.
    LaunchedEffect(Unit) {
        weather = WeatherRepository.currentWeather(context)
    }

    // RAM: refresh periodically so the ring/panel don't go stale while idle,
    // and re-check both usage-access and lock-gesture enablement each pass
    // in case the user just granted either in Settings and came back.
    LaunchedEffect(Unit) {
        while (true) {
            ramStatus = RamBoosterRepository.currentStatus(context)
            hasUsageAccess = RamBoosterRepository.hasUsageAccess(context)
            hasLockGestureEnabled = AccessibilityLockRepository.isServiceEnabled(context)
            delay(5000)
        }
    }

    val dayProgress = remember(now) {
        (now.hour * 60 + now.minute) / (24f * 60f)
    }

    // Shared by the ring's rocket icon and the RAM panel's BOOST button —
    // one implementation, two entry points into it.
    fun triggerBoost() {
        scope.launch {
            boostState = BoostUiState.Boosting
            val result = RamBoosterRepository.boost(context)
            ramStatus = RamBoosterRepository.currentStatus(context)
            boostState = BoostUiState.Done(result)
        }
    }

    // Double-tap anywhere on the HUD background locks the screen. This lives
    // on the root Modifier rather than a dedicated overlay because Compose's
    // pointer input dispatch already does the right thing here: a tap that
    // lands on the ring or the RAM panel gets consumed by *their* clickable
    // modifiers first, so detectTapGestures (which defaults to
    // requireUnconsumed = true) never sees it. Only genuine background taps
    // reach here — no manual hit-testing/exclusion-zone math needed.
    //
    // If the service isn't enabled yet, the first double-tap sends the user
    // to Accessibility Settings instead of silently doing nothing — same
    // "explain, don't just fail" pattern as the RAM booster's usage-access gate.
    Column(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(hasLockGestureEnabled) {
                detectTapGestures(
                    onDoubleTap = {
                        if (hasLockGestureEnabled) {
                            AccessibilityLockRepository.requestLock()
                        } else {
                            AccessibilityLockRepository.openAccessibilitySettings(context)
                        }
                    }
                )
            }
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceEvenly
    ) {
        OrbitRing(progress = dayProgress) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = now.format(TIME_FORMAT),
                    color = TextPrimary,
                    style = MaterialTheme.typography.displayMedium,
                    modifier = Modifier.clickable { HudIntents.openAlarms(context) }
                )
                Text(
                    text = now.format(DATE_FORMAT),
                    color = TextSecondary,
                    style = MaterialTheme.typography.bodyMedium,
                    modifier = Modifier.clickable { HudIntents.openCalendarToday(context) }
                )
                Row(verticalAlignment = Alignment.CenterVertically) {
                    WeatherLine(weather)
                    IconButton(
                        onClick = { triggerBoost() },
                        modifier = Modifier.padding(start = 4.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RocketLaunch,
                            contentDescription = "Boost RAM",
                            tint = if (boostState is BoostUiState.Boosting) TextDisabled else NeonCyan
                        )
                    }
                }
            }
        }

        RamBoosterPanel(
            status = ramStatus,
            hasUsageAccess = hasUsageAccess,
            boostState = boostState,
            onBoostClick = { triggerBoost() }
        )

        // Dialer + news feed triggers — both open as modal Dialogs above
        // everything else, so they don't need their own place in the
        // SpaceEvenly layout beyond this one row.
        Row(horizontalAlignment = Alignment.CenterHorizontally) {
            IconButton(onClick = { showDialer = true }) {
                Icon(imageVector = Icons.Filled.Call, contentDescription = "Open dialer", tint = NeonCyan)
            }
            IconButton(onClick = { showNewsFeed = true }) {
                Icon(imageVector = Icons.Filled.Newspaper, contentDescription = "Open news feed", tint = NeonCyan)
            }
        }

        // Voice assistant: "Open X" / "Boost RAM" / "Lock Screen" all funnel
        // through the same repositories the buttons above already call —
        // this isn't a second implementation of any of them.
        VoiceAssistantEntryPoint()

        Text(
            text = if (hasLockGestureEnabled) {
                "Double-tap background to lock"
            } else {
                "Double-tap background to enable lock gesture"
            },
            color = TextDisabled,
            style = MaterialTheme.typography.labelSmall
        )
    }

    if (showDialer) {
        DialerModal(onDismiss = { showDialer = false })
    }
    if (showNewsFeed) {
        RssFeedPopup(onDismiss = { showNewsFeed = false })
    }
}

@Composable
private fun WeatherLine(weather: WeatherSnapshot?) {
    val text = if (weather == null) {
        "…"
    } else {
        "${weather.condition.glyph} ${weather.tempC}°"
    }
    Text(
        text = text,
        color = NeonCyan,
        style = MaterialTheme.typography.labelSmall,
        modifier = Modifier.padding(top = 6.dp)
    )
}
