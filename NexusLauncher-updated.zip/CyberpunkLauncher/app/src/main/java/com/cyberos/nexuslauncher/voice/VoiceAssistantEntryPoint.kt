package com.cyberos.nexuslauncher.voice

import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle

/**
 * Everything a screen needs to add voice commands: `VoiceAssistantEntryPoint()`.
 * Handles the RECORD_AUDIO permission gate, owns the [VoiceAssistantController]
 * for as long as this stays in composition, and renders [VoiceMicOrb].
 *
 * Usage, e.g. dropped into a corner of OrbitHudScreen's Column:
 * ```
 * VoiceAssistantEntryPoint(modifier = Modifier.align(Alignment.End))
 * ```
 */
@Composable
fun VoiceAssistantEntryPoint(modifier: Modifier = Modifier) {
    VoiceAssistantPermissionGate(modifier = modifier) {
        val controller = rememberVoiceAssistantController()
        val state by controller.state.collectAsStateWithLifecycle()

        VoiceMicOrb(
            state = state,
            onStartListening = controller::startListening,
            onStopListening = controller::stopListening
        )
    }
}
