package com.cyberos.nexuslauncher.security

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.text.TextUtils

/**
 * Thin front door for the double-tap-to-lock gesture.
 *
 * Accessibility services are "special access" like Usage Access was for the
 * RAM booster: no runtime permission dialog, the user has to flip it on in
 * Settings themselves. [isServiceEnabled] checks the system setting string
 * directly (the standard way to check this, short of AccessibilityManager's
 * getEnabledAccessibilityServiceList) rather than relying on
 * [LockAccessibilityService.isConnected], since that only becomes true
 * *after* the system finishes binding the service — there's a gap right
 * after the user enables it in Settings where it's "enabled" but not yet
 * connected.
 */
object AccessibilityLockRepository {

    fun isServiceEnabled(context: Context): Boolean {
        val expectedComponent = "${context.packageName}/${LockAccessibilityService::class.java.name}"
        val enabledServices = Settings.Secure.getString(
            context.contentResolver,
            Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
        ) ?: return false

        return TextUtils.SimpleStringSplitter(':').apply { setString(enabledServices) }
            .asSequence()
            .any { it.equals(expectedComponent, ignoreCase = true) }
    }

    fun openAccessibilitySettings(context: Context) {
        context.startActivity(
            Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
    }

    /** True only if the service was connected and the lock actually fired. */
    fun requestLock(): Boolean = LockAccessibilityService.requestLock()
}

private fun TextUtils.SimpleStringSplitter.asSequence(): Sequence<String> = sequence {
    while (hasNext()) yield(next())
}
