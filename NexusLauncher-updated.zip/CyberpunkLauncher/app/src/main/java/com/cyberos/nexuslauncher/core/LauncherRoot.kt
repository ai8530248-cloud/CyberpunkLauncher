package com.cyberos.nexuslauncher.core

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.drawer.AppDrawerScreen
import com.cyberos.nexuslauncher.hud.OrbitHudScreen
import com.cyberos.nexuslauncher.ui.theme.GridLine
import com.cyberos.nexuslauncher.ui.theme.VoidBlack
import kotlinx.coroutines.launch

private const val OPEN_ON_HALF = 0.5f
private const val FLING_VELOCITY_THRESHOLD = 600f
private const val SETTLE_DURATION_MS = 260

/**
 * [revealProgress] (0f closed .. 1f fully open) drives both the drawer's
 * translationY and a dimming scrim over the HUD, and is shared by two
 * independent drag zones — the HUD background (swipe up to open) and a
 * small grab handle at the top of the drawer (swipe down to close) — kept
 * apart from the wheel's own rotation drag lower in [AppDrawerScreen] so
 * the two gestures never fight each other.
 *
 * Both [OrbitHudScreen] and [AppDrawerScreen] stay mounted the whole time;
 * the drawer just translates fully below the screen when "closed" rather
 * than being removed from composition, so its scanned app list isn't
 * thrown away and rescanned on every open.
 *
 * [collapseSignal] lets a caller (MainActivity, on a fresh Home-press
 * Intent) force the drawer shut from outside — bump it and this reacts.
 */
@Composable
fun LauncherRoot(
    modifier: Modifier = Modifier,
    collapseSignal: Int = 0
) {
    val scope = rememberCoroutineScope()

    var containerHeightPx by remember { mutableFloatStateOf(1f) }
    val revealProgress = remember { Animatable(0f) }
    var isDrawerOpen by remember { mutableStateOf(false) }

    fun settleTo(target: Float) {
        scope.launch {
            revealProgress.animateTo(target, animationSpec = tween(SETTLE_DURATION_MS))
            isDrawerOpen = target > OPEN_ON_HALF
        }
    }

    fun commitDrag(velocity: Float) {
        val shouldOpen = when {
            velocity < -FLING_VELOCITY_THRESHOLD -> true
            velocity > FLING_VELOCITY_THRESHOLD -> false
            else -> revealProgress.value > OPEN_ON_HALF
        }
        settleTo(if (shouldOpen) 1f else 0f)
    }

    // Same formula for both drag zones: finger up (negative delta in
    // Compose's Y-down convention) increases reveal, finger down decreases
    // it — true regardless of whether the drag started on the HUD or the
    // drawer's own grab handle.
    fun onDragDelta(delta: Float) {
        scope.launch {
            val next = (revealProgress.value - delta / containerHeightPx).coerceIn(0f, 1f)
            revealProgress.snapTo(next)
        }
    }

    BackHandler(enabled = isDrawerOpen) { settleTo(0f) }

    LaunchedEffect(collapseSignal) {
        if (collapseSignal > 0 && (isDrawerOpen || revealProgress.value > 0f)) {
            settleTo(0f)
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .onSizeChanged { containerHeightPx = it.height.toFloat().coerceAtLeast(1f) }
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .then(
                    if (!isDrawerOpen) {
                        Modifier.draggable(
                            orientation = Orientation.Vertical,
                            state = rememberDraggableState { delta -> onDragDelta(delta) },
                            onDragStopped = { velocity -> commitDrag(velocity) }
                        )
                    } else {
                        Modifier
                    }
                )
        ) {
            OrbitHudScreen()
        }

        if (revealProgress.value > 0f) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(VoidBlack)
                    .alpha(revealProgress.value * 0.6f)
            )
        }

        Box(
            modifier = Modifier
                .fillMaxSize()
                .graphicsLayer { translationY = (1f - revealProgress.value) * size.height }
        ) {
            AppDrawerScreen()

            Box(
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .padding(top = 10.dp)
                    .width(48.dp)
                    .height(5.dp)
                    .background(GridLine, RoundedCornerShape(50))
                    .draggable(
                        orientation = Orientation.Vertical,
                        state = rememberDraggableState { delta -> onDragDelta(delta) },
                        onDragStopped = { velocity -> commitDrag(velocity) }
                    )
            )
        }
    }
}
