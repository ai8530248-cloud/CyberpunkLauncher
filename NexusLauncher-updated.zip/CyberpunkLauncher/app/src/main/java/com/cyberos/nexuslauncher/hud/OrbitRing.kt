package com.cyberos.nexuslauncher.hud

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.cyberos.nexuslauncher.ui.theme.GridLine
import com.cyberos.nexuslauncher.ui.theme.NeonCyan
import com.cyberos.nexuslauncher.ui.theme.NeonPurple

/**
 * The HUD's central ring: a faint full-circle track plus a gradient arc
 * that sweeps proportionally to [progress] (0f..1f). [content] is placed
 * dead-center — the clock lives there, weather sits just below it as
 * ordinary composables rather than being drawn on the canvas, so text stays
 * crisp and layout-system-driven instead of hand-positioned in Canvas space.
 */
@Composable
fun OrbitRing(
    progress: Float,
    modifier: Modifier = Modifier,
    diameter: androidx.compose.ui.unit.Dp = 220.dp,
    strokeWidth: androidx.compose.ui.unit.Dp = 6.dp,
    content: @Composable BoxScope.() -> Unit
) {
    Box(
        modifier = modifier.size(diameter),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(diameter)) {
            val strokePx = strokeWidth.toPx()
            val inset = strokePx / 2f
            val arcSize = androidx.compose.ui.geometry.Size(
                width = size.width - strokePx,
                height = size.height - strokePx
            )
            val topLeft = androidx.compose.ui.geometry.Offset(inset, inset)

            // Faint background track, full circle.
            drawArc(
                color = GridLine,
                startAngle = 0f,
                sweepAngle = 360f,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )

            // Progress arc, starts at 12 o'clock, sweeps clockwise.
            val sweep = 360f * progress.coerceIn(0f, 1f)
            drawArc(
                brush = Brush.sweepGradient(listOf(NeonCyan, NeonPurple, NeonCyan)),
                startAngle = -90f,
                sweepAngle = sweep,
                useCenter = false,
                topLeft = topLeft,
                size = arcSize,
                style = Stroke(width = strokePx, cap = StrokeCap.Round)
            )
        }

        content()
    }
}
