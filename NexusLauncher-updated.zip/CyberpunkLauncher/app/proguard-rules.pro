# Add project-specific ProGuard rules here as native/reflection-based
# dependencies are introduced (none yet at scaffold stage).
